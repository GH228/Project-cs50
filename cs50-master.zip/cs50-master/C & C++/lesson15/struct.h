typedef struct{
    char* name;
    char* age;
} student;