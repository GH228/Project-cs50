#include <iostream>
#include <cstring>

using namespace std;

int main(){
    char surname[20];
    char name[] = {'D', 'E', 'B', 'I', 'L'};
    char name2[] = "IDIOT";

    // cout << name << name2 << endl;

    cout << strlen(name) << endl;

    return 0;
}