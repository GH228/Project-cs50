#include <stdio.h>
#include <cs50.h>

int main(void){
    int a = 4;
    int b = 5;

    if (a == b)
    {
        printf("a - b");
    }
}