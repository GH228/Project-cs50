#include <cs50.h>
#include <stdio.h>

int main(void)
{
    /* string start = get_string("What is your name? <Dan, Roma>");

    switch(start)
    {
        case 'Dan':
            char char1 = get_char("Do you eat shit? <y, n>");
            switch(char1){
                case 'y':
                    printf("Of course you debilous , strange and stupid child...")
            }
            break;
        case 'Roma':
            printf("Hi, creator of this program");
            char char1 = get_char("How are you?");
            break;
    }
    if (start == "Dan"){
        switch(start)
        {
            case 'Dan':
                char char1 = get_char("Do you eat shit? <y, n>");
                switch(char1){
                    case 'y':
                        printf("Of course you debilous , strange and stupid child...")
                }
        }
    }*/


}