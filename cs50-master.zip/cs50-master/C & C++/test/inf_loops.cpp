#include<iostream>

using namespace std;

int main(){
    bool Arg = true;
    while(Arg == true){
       cout << "A" << endl;
    }
}